<?php
/***************************************************************************
*                            Dolphin Smart Community Builder
*                              -------------------
*     begin                : Mon Mar 23 2006
*     copyright            : (C) 2007 BoonEx Group
*     website              : http://www.boonex.com
* This file is part of Dolphin - Smart Community Builder
*
* Dolphin is free software; you can redistribute it and/or modify it under
* the terms of the GNU General Public License as published by the
* Free Software Foundation; either version 2 of the
* License, or  any later version.
*
* Dolphin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* See the GNU General Public License for more details.
* You should have received a copy of the GNU General Public License along with Dolphin,
* see license.txt file; if not, write to marketing@boonex.com
***************************************************************************/

bx_import('BxDolModule');

class MeBclModule extends BxDolModule {
	protected $dir = "";
	protected $cssTxt = "";

    function MeBclModule(&$aModule) {        
        parent::BxDolModule($aModule); 
		$this->dir = 'me/banckle/templates/base/';
		$this->cssTxt = '<style>
		
		fieldset{
		border:none;
		}
		
		input, textarea{
		width:275px; ; border:1px solid #cccccc; font:12px arial; font-weight:bold; padding:2px;
		}
		
		select{
		width:275px; ; border:1px solid #cccccc; font:12px arial; font-weight:bold; padding:2px;
		}
		
		div.adm-design-box{
		width:660px;
		}
		
	
		 .banckle-lc-wp-container{
		 background: #f5f5f5;
		  -moz-box-shadow:    inset 2px 2px 2px #fff;
 		  -webkit-box-shadow: inset 2px 2px 2px #fff;
  		  box-shadow:         inset 2px 2px 2px #fff;
          border:1px solid #DBDBDB;
		  float:left;
		  padding:0px;
		  margin-top:5px;
		  padding:5px;
		  width:650px;
		 		 
		 }
		
		div.adm-db-content{
		background:#f8f8f8;
		padding:0px;
		height:5px;
		margin:0px;
		}
		
		
div.adm-db-head{  
	     background: url('.$this->dir.'images/banckle-lc-wp-top1.gif) top left repeat-x #9ecfe6;
		 height:30px;
		 padding:3px;
		 font:15px/20px Times New Roman, Times, serif;
		 font-weight:normal;
		 text-shadow: 1px 1px 1px #fff;
		 }
		 
		 
div.adm-db-head a{
		 color:#fff;			
		 }
		 
div.adm-db-head a:hover{
  		 color:#1280b4;
		 text-decoration:none;	
		 }
		 
div.adm-db-head img{
  
		 line-height:18px;
		 display:block-inline;
		 vertical-align:middle;
		 margin-top:-5px;
		 padding-top:3px;
		 padding-right:5px;
		 
		
		 }
		 
.bottom-text{
		 display:block-inline; 
		 clear:both;
		 font:12px arial;
		 font-weight:bold;
		 }
		 
.bottom-text a{
		 font:12px arial;
		 font-weight:normal;
		 color:#21759b;
		 }

		 
.continue-btn input{
		 background: url('.$this->dir.'images/continue.png) no-repeat; width:89px; height:32px; border:none;
		 color:#FFFFFF;
		 font:12px arial;
		 float:left;
		 margin-top:5px;
		 margin-bottom:10px;
		 margin-left:96px;
		 cursor:pointer;
		 }
		 
.button-active{
		 background: url('.$this->dir.'images/active.png) no-repeat; width:120px; height:32px; border:none;
		 cursor:pointer;
		 color:#FFFFFF;
		 font:12px arial;
		 float:right;
		 margin-bottom:10px;
		 margin-right:-125px;

		 }
		 
		 
.login-bg{
		 background: url('.$this->dir.'images/bg_login.png) no-repeat #fee180;
		 width:496px;
		 padding-left:150px;
		 padding-top:25px;
		 padding-bottom:15px;
		 margin-top:10px;
		 -webkit-border-bottom-right-radius: 5px;
	-webkit-border-bottom-left-radius: 5px;
	-moz-border-radius-bottomright: 5px;
	-moz-border-radius-bottomleft: 5px;
	border-bottom-right-radius: 5px;
	border-bottom-left-radius: 5px;
		 }
		 
.button-primary{
		 display:block;
		 -webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		cursor:pointer;
		color:#fff;
		background-image: linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -o-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -moz-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -webkit-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -ms-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -webkit-gradient(	linear,	left bottom, left top,
											color-stop(0.35, rgb(0,111,162)),
											color-stop(0.94, rgb(51,161,212)));

		-webkit-box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.8);
		-moz-box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.8);
		box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.4); 
		border:1px solid #ffffff;
		 }
		 
		 
.button-primary a{
		 display:block;
		 -webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		cursor:pointer;
		color:#fff;
		font:12px arial;
		padding:2px;
		font-weight:bold;
		text-align:center;
		background-image: linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -o-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -moz-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -webkit-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -ms-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -webkit-gradient(	linear,	left bottom, left top,
											color-stop(0.35, rgb(0,111,162)),
											color-stop(0.94, rgb(51,161,212)));

		-webkit-box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.8);
		-moz-box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.8);
		box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.4); 
		border:1px solid #ffffff;
		text-decoration:none;
		 } 
		 
.button-primary-cancle{
		 display:block;
		 -webkit-border-radius: 5px;
		-moz-border-radius: 5px;
		border-radius: 5px;
		cursor:pointer;
		color:#fff;
		background-image: linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -o-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -moz-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -webkit-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -ms-linear-gradient(bottom, rgb(0,111,162) 35%, rgb(51,161,212) 94%);
		background-image: -webkit-gradient(	linear,	left bottom, left top,
											color-stop(0.35, rgb(0,111,162)),
											color-stop(0.94, rgb(51,161,212)));

		-webkit-box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.8);
		-moz-box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.8);
		box-shadow: inset 1px 1px 1px 1px rgba(255, 255, 255, 0.4); 
		border:1px solid #ffffff;
		width:150px;
		 }
		 
		 
		
			
						
						 
						  
						  
					 }

					 .banckle-lc-wp-container IMG{ border:0px;}

					 .banckle-lc-wp-container h3{
						  clear:both;
						  display:block;
						  float:left;
						  padding: 10px 0px 0px 0px ;
						  margin:0px;
						  background: url('.$this->dir.'images/banckle-lc-wp-top1.gif) top left repeat-x;
						  height:42px;
						  text-indent:15px;
						  font-size:16px;
						  color:#333;
						  width:100%;
						  font-weight:bold;
					 }

					 .banckle-lc-wp-container-left{
						  display:inline;
						  float:left;
						  padding:10px;
						  margin:0px;
						  width:130px;
					 }

					 .banckle-lc-wp-container-right{
						  display:inline;
						  float:right;
						  width:620px;
						  padding:10px;
						  margin:0px;
						  _font:12px/20px Georgia, "Times New Roman", Times, serif;
						  color:#666;
					 }

					 OL{ margin:10px 0px;}
					 li{margin-left:30px;}

					 .banckle-lc-wp-container-right TEXTAREA{
						  border:1px inset #eee;
						  background:#F8F8F8;
						  padding:5px;
						  margin-left:0px;
						  margin-bottom:5px;
						  _height:100px;
						  _width:600px;
					 }
					 div.row {
						  clear: both;
						  padding-top: 5px;
					 }

					 div.row span.label {
						  float: left;
						  width: 240px;
						  text-align: right;
					 }

					 div.row span.formw {
						  float: left;
						  width: 235px;
						  text-align: left;
					 }

					 .steps3{
						  display:block;
						  clear:both;
						  float:left;
						  background:url('.$this->dir.'images/3steps.png) top left no-repeat #ccc;
						  width:646px;
						  height:148px;
						  margin-top:20px;
					 }
					 .steps3 UL{ padding:0px; margin:0px; margin-top:55px; font:12px/18px Arial, Helvetica, sans-serif}
					 .steps3 UL LI{ padding:0px; margin:0px; display:inline; float:left; width:190px; padding:0px 12px;  }

					 .postbox table.form-table{ margin-bottom:10px;}

					 .wp-lc-mesg-success{ display:block; clear:both; float:left; width:646px; padding:88px 0px 0px 0px; text-align: center; height:60px; background:url('.$this->dir.'images/bg_success.png) top left no-repeat #ccc; font:bold 12px arial}

					 .wp-lc-login{ display:block; clear:both; float:left; width:646px; padding:14px 0px 14px 0px; text-align: center; height:120px; background:url('.$this->dir.'images/bg_login.png) top left no-repeat #ccc; font:bold 12px arial}

					 .wp-lc-error{ display:block; clear:both; float:left; width:646px; padding:78px 0px 0px 0px; text-align: center; height:70px; background:url('.$this->dir.'images/bg_error.png) top left no-repeat #ccc; font:bold 12px arial}

					 .wp-lc-deploy{ display:block; clear:both; float:left; width:646px; padding:24px 0px 24px 0px; text-align: center; height:70px; background:url('.$this->dir.'images/bg_deployment.png) top left no-repeat #ccc; font:bold 12px arial}

					 .wp-lc-login-form{ display:block; clear:both; float:left; width:646px; padding:14px 0px 0px 0px; text-align: center; background:url('.$this->dir.'images/bg_logon_top.png) top left no-repeat #FEE180; font:bold 12px arial}
					 .wp-lc-login-form-btm{background:url('.$this->dir.'images/bg_logon_btm.png) bottom left no-repeat; float:left; padding-bottom:20px; width:100%}
					 .wp-lc-login-form-error{ display:block; clear:both; float:left; width:624px; padding:2px 10px; margin:4px 0px 4px 0px; text-align:left; background:#FFEBE8; border:1px solid #CC0000}

					 .wp-lc-login-form legend{ border-bottom: 1px solid #FEF3CC; clear: both; display: block; float: left; font: bold 14px arial;  margin: 15px 0px 5px 0px;  text-align: left;  width: 100%; background:#FEE9A5; padding:5px;}

					 fieldset {
						  margin: 1.5em 0 1.5em 0;padding: 0; /*background-color:#DBDBDB*/}
					 legend {
						  margin-left: 1em;
						  color: #000000;
						  font-weight: bold;
					 }



				</style>';
    }
		
	function BanckleLiveChatDeploymentForm($deptId, $deptName, $token, $loginId, $password) {
		
	$html = '<tr></td><form method="post" action="'.BX_DOL_URL_MODULES.'?r=banckle/settings/&action=deploy">
	 	 <div>
	 		  <div>
	 				<div style="width: 580px; padding: 5px; margin: 0px auto; line-height:26px;">
	 					 <fieldset>
	 						  <legend style="margin:0px; padding:0px;">Deployment</legend>
	 						  <div>
	 								<span><label style="width:100px; float:left">Deployment:</label></span>
	 								<span><input value="New Deployment" type="text" name="deployment" id="deployment" style="width:275px; float:left; clear:right"/></span>
	 						  </div>
	 						  <div>
	 								<span><label style="width:100px; float:left; clear:left">Title:</label></span>
	 								<span><input value="Live Chat" type="text" name="title" id="title" style="width:275px; float:left; clear:right"/></span>
	 						  </div>
	 						  <div>
	 								<span><label style="width:100px; float:left; clear:left">Copyright Text:</label></span>
	 								<span class="formw"><input value="Copyright is reserved by Banckle." type="text" name="copyright" id="copyright" style="width:275px; float:left; clear:right"/></span>
	 						  </div>
	 					 </fieldset>
	 					 <fieldset>
	 						  <legend style="padding:0px; margin:0px">Messages</legend>
	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Invite:</label></span>
	 								<span class="formw"><textarea type="text" name="inviteMessage" id="inviteMessage" style="width:275px">Do you have any questions?</textarea></span>
	 						  </div>
	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Online:</label></span>
	 								<span class="formw"><textarea type="text" name="welcomeMessage" id="welcomeMessage" style="width:275px">Welcome to Banckle</textarea></span>
	 						  </div>

	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Offline:</label></span>
	 								<span class="formw"><textarea type="text" name="unavailableMessage" id="unavailableMessage" style="width:275px">Sorry, our service is unavailable now.</textarea></span>
	 						  </div>
	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Waiting:</label></span>
	 								<span class="formw"><textarea type="text" name="waitingMessage" id="waitingMessage" style="width:275px">Please stand by while we connect you to the next available operator...</textarea></span>
	 						  </div>
	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Exit:</label></span>
	 								<span class="formw"><textarea type="text" name="finalMessage" id="finalMessage" style="width:275px">Thank you for choosing Banckle.</textarea></span>
	 						  </div>
	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Department:</label></span>
	 								<span class="formw"><input type="hidden" name="departments" id="departments" value="'.$deptId.'" />
	 									 <input type="hidden" name="loginId" id="loginId" style="width:275px" value="'.$loginId.'"/>
	 									 <input type="hidden" name="password" id="password"  style="width:275px" value="'.$password.'"/>
	 									 <input type="hidden" name="token" id="token" value="'.$token.'" style="width:275px"/>
	 									 <input disabled="true" type="text" name="deptName" id="deptName" value="'.$deptName.'" style="width:275px"/>
	 								</span>
	 						  </div>
	 					 </fieldset>
	 					 <fieldset>
	 						  <legend style="padding:0px; margin:0px">Appearance</legend>
	 						  <div class="row">
	 								<span><label style="float:left; text-align:left; width:100px ;">Position</label></span>
	 								<span class="formw"><select name="blcLocation" id="blcLocation"><option value="banckleLiveChatWidget">Widget</option><option value="banckleLiveChatTopLeft">Top Left</option><option value="banckleLiveChatTopRight">Top Right</option><option value="banckleLiveChatBottomLeft">Bottom Left</option><option value="banckleLiveChatBottomRight">Bottom Right</option></select> </span>
	 						  </div>
	 					 </fieldset>

	 					 <div class="row">
	 						  
	 						  <span class="formw"><input type="submit" class="button-primary" style="width:150px; margin-bottom:10px;" value="Create Deployment" /></span>
	 					 </div>

	 				</div><!--width 580px; -->
	 		  </div><!--only for bottom bg -->
	 	 </div><!--wp-lc-login-form -->
	 </form></td></tr>';
	
	return $html;
}
	
	function banckleLiveChatRequest($url, $method="GET", $headerType="XML", $xmlsrc="") {

	 $method = strtoupper($method);
	 $headerType = strtoupper($headerType);
	 $session = curl_init();
	 curl_setopt($session, CURLOPT_URL, $url);
	 if ($method == "GET") {
		  curl_setopt($session, CURLOPT_HTTPGET, 1);
	 } else {
		  curl_setopt($session, CURLOPT_POST, 1);
		  curl_setopt($session, CURLOPT_POSTFIELDS, $xmlsrc);
		  curl_setopt($session, CURLOPT_CUSTOMREQUEST, $method);
	 }
	 curl_setopt($session, CURLOPT_HEADER, false);
	 if ($headerType == "XML") {
		  curl_setopt($session, CURLOPT_HTTPHEADER, array('Accept: application/xml', 'Content-Type: application/xml'));
	 } else {
		  curl_setopt($session, CURLOPT_HTTPHEADER, array("Content-Type: application/json"));
	 }
	 curl_setopt($session, CURLOPT_RETURNTRANSFER, true);
	 if (preg_match("/^(https)/i", $url))
		  curl_setopt($session, CURLOPT_SSL_VERIFYPEER, false);
	 $result = curl_exec($session);
	 curl_close($session);
	 return $result;
}
	
	function actionSettings(){
	
		if (!$GLOBALS['logged']['admin']) { // check access to the page
            $this->_oTemplate->displayAccessDenied ();
            return;
        }

        $this->_oTemplate->pageStart(); // all the code below will be wrapped by the admin design

	    $iId = $this->_oDb->getSettingsCategory(); // get our setting category id
	    if(empty($iId)) { // if category is not found display page not found
            echo MsgBox(_t('_sys_request_page_not_found_cpt'));
            $this->_oTemplate->pageCodeAdmin (_t('_me_bcl'));
            return;
        }
		
		$me_bcl_script = $this->_oDb->getOption($iId,'me_bcl_script');
		
		$aMenu = array(
                'me_bcl_main'      => array('title' => 'Dashboard', 'href' => BX_DOL_URL_MODULES . '?r=banckle/administration/'), 
                'me_bcl_settings'  => array('title' => 'Settings', 'href' => BX_DOL_URL_MODULES . '?r=banckle/settings/'),
            );
		
		$sResult .= $this->cssTxt;

		$sResult .= "<div class='banckle-lc-wp-container'><table><tr><td>";
		if (!function_exists('curl_init')) {
			$sResult .= "Banckle Live Chat needs the CURL PHP extension.";
		}
		if (!function_exists('json_decode')) {
			$sResult .= "Banckle Live Chat needs the JSON PHP extension.";
		}
		
		$sResult .= "</td></tr>";
		
		if($me_bcl_script == "")
		{
			
			$sResult .= "<tr valign='top'><td><div style='font-size:11px; width:510px;'>Banckle Live Chat Plugin has been successfully installed into your Dolphin.</div></td></tr>";
			
			if (isset($_REQUEST['action']) && $_REQUEST['action'] === "deploy")
			{
				if ($_SERVER['REQUEST_METHOD'] == 'POST') {
					$loginId = $_POST['loginId'];
					$password = $_POST['password'];
					$token = $_POST['token'];
					$deptId = $_POST['departments'];

					$location = $_POST['blcLocation'];

					$deployment = $_POST['deployment'];
					$deployment = $deployment === "" ? "New Deployment" : $deployment;

					$title = $_POST['title'];
					$title = $title === "" ? "Live Chat" : $title;

					$copyright = $_POST['copyright'];
					$copyright = $copyright === "" ? "Copyright is reserved by Banckle." : $copyright;

					$inviteMessage = $_POST['inviteMessage'];
					$inviteMessage = $inviteMessage === "" ? "Do you have any questions?" : $inviteMessage;

					$unavailableMessage = $_POST['unavailableMessage'];
					$unavailableMessage = $unavailableMessage === "" ? "Sorry, our service is unavailable now." : $unavailableMessage;

					$waitingMessage = $_POST['waitingMessage'];
					$waitingMessage = $waitingMessage === "" ? "Please stand by while we connect you to the next available operator..." : $waitingMessage;

					$welcomeMessage = $_POST['welcomeMessage'];
					$welcomeMessage = $welcomeMessage === "" ? "Welcome to Banckle" : $welcomeMessage;

					$finalMessage = $_POST['finalMessage'];
					$finalMessage = $finalMessage === "" ? "Thank you for choosing Banckle." : $finalMessage;

					$deployXML = new SimpleXMLElement("<?xml version=\"1.0\" encoding=\"UTF-8\"?><deployment></deployment>");
					$deployXML->addChild("name", $deployment);
					$deployXML->addChild("theme", "Theme-4");
					$deployXML->addChild("title", $title);
					$deployXML->addChild("copyright", $copyright);
					$deployXML->addChild("unavailableMessage", $unavailableMessage);
					$deployXML->addChild("waitingMessage", $waitingMessage);
					$deployXML->addChild("welcomeMessage", $welcomeMessage);
					$deployXML->addChild("finalMessage", $finalMessage);
					$deployXML->addChild("inviteMessage", $inviteMessage);
					$deployXML->addChild("departments", $deptId);
					$deployXML->addChild("exitSurvey", "");
					$deployXML->addChild("enableAutoInvite", "false");
					$deployXML->addChild("inviteTimeout", "60");
					$deployXML->addChild("autoInviteImage", "");
					$deployXML->addChild("enableProactiveInvite", "true");
					//$deployXML->addChild("proactiveInviteImage","");
					$deployXML->addChild("enableInvitationFilter", "false");
					$deployXML->addChild("invitationFilterType", "0");
					$deployXML->addChild("linkType", "0");
					$deployXML->addChild("themeFlags", "0");

					 //echo $deployXML->asXML()."<hr>";
					$xmlDeploy = $this->banckleLiveChatRequest('https://apps.banckle.com/em/api/deployments.xml?_token=' . $token, "POST", "XML", $deployXML->asXML());
					 //echo $xmlDeploy."<hr>";
					$xmlDeploy = new SimpleXMLElement(utf8_encode($xmlDeploy));
					
					$sResult .= '<tr><td><form method="post" action="'.BX_DOL_URL_MODULES .'?r=banckle/updateoptions/">										  
		  										  <div class="wp-lc-deploy">
		  												<div style="width: 580px; padding: 5px; margin: 0px auto; line-height:26px">
		  													 <div class="row" style=" font-weight: normal;">
		  														  <b>Congratulations!</b> Banckle Live Chat Deployment Widget is <b>successfully</b> created.
		  													 </div>

		  													 <div class="row">
		  														  <span class="label">
		  																<input type="hidden" name="me_bcl_script" id="me_bcl_script" value="'.$xmlDeploy->id.'"/>
		  																<input type="hidden" name="me_bcl_loginId" id="me_bcl_loginId" value="'.$loginId.'"/>
		  																<input type="hidden" name="me_bcl_password" id="me_bcl_password"  value="'.$password.'"/>
		  																<input type="hidden" name="me_bcl_location" id="me_bcl_location" value="'.$location.'"/>
		  																		  															
		  														  </span>
		  														  <span class="formw"><input style="margin-top:8px" type="submit" class="button-primary" value="Activate Live Chat" /></span>
		  													 </div>
		  												</div>
		  										  </div>
		  									 </form></td></tr>';
				}
				
			}
			if (isset($_REQUEST['action']) && $_REQUEST['action'] === "dept")
			{
				if ($_SERVER['REQUEST_METHOD'] == 'POST') {
					$loginId = $_POST['loginId'];
					$password = $_POST['password'];
					$dept = $_POST['deptName'];
					$deptId = isset($_POST['deptId']) ? $_POST['deptId'] : null;
					$dept = $dept === "" ? "New Department" : $dept;
					$token = '';

					 $arr;
					$content = $this->banckleLiveChatRequest('https://apps.banckle.com/api/authenticate?userid=' . $loginId . '&password=' . $password . '&sourceSite=' . BX_DOL_URL_ROOT . '&platform=dolphin', "GET", "JSON", "");

					if ($content !== false) {
						$arr = json_decode($content, true);
						if (array_key_exists('error', $arr)) {
									 $sResult .= "<tr><td><div>Oops, " . $arr['error']['details'] . "<br/>
					 										  <input style=\"margin-top:8px; width:100px; margin:auto;\" type=\"submit\" onclick=\"parent.location='".BX_DOL_URL_MODULES."?r=banckle/settings/&action=signup'\" value=\"Try Again\" /></div></td></tr>";
						} else {
							$token = $arr['return']['token'];
							if (!isset($deptId)) {
								$jsonDept = $this->banckleLiveChatRequest('https://apps.banckle.com/em/api/departments.js?_token=' . $token, "POST", "JSON", '{displayName : "' . $dept . '", members : ["' . $loginId . '"]}');
								$jsonDeptArray = json_decode($jsonDept, true);
								if (array_key_exists('id', $jsonDeptArray)) {
									$deptId = $jsonDeptArray['id'];
								}
							}
							if ($deptId === "") {
								$sResult .= "<tr><td><div>Oops $jsonDept, Department is not created, Please <br/><input style=\"margin-top:8px; width:100px; margin:auto;\" type=\"submit\" onclick=\"parent.location='".BX_DOL_URL_MODULES."?r=banckle/settings/&action=dept'\" value=\"Try Again\" /></div></td></tr>";
							} else {
								$sResult .= $this->BanckleLiveChatDeploymentForm($deptId, $dept, $token, $loginId, $password);
							}
						}
					}
				}//end action dept post
			}
			if (isset($_REQUEST['action']) && $_REQUEST['action'] === "signup")
			{
				
				if ($_SERVER['REQUEST_METHOD'] == 'POST') {
					$loginId = $_POST['loginId'];
					$password = $_POST['password'];
					$email = $_POST['email'];

					$arr;
					$content = $this->banckleLiveChatRequest('https://apps.banckle.com/api/registeruser?uid=' . $loginId . '&password=' . $password . '&email=' . $email, "GET", "JSON", "");

					if ($content !== false) {
						$arr = json_decode($content, true);
						//var_dump($arr);
						if (array_key_exists('error', $arr)) {
							
							$sResult .= "<tr><td><div>Oops, " . $arr['error']['details'] . "<br/><br/>
					 										  <input style=\"margin-top:10px; width:100px; margin:auto; float:left\" class=\"button-primary\" type=\"submit\" onclick=\"parent.location='".BX_DOL_URL_MODULES."?r=banckle/settings/&action=signup'\" value=\"Try Again\" /></div></td></tr>";
						}
						else
						{
							$sResult .= "<tr><td><div>Your Banckle account has been created successfully.</div>
						  									 <form method=\"post\" action=\"".BX_DOL_URL_MODULES."?r=banckle/settings/&action=dept\">
						  										  <div>
						  												<div style=\"width: 580px; padding: 5px; margin: 0px auto; line-height:26px;\">
						  													 <div>
						  														  <span><label>Department:</label></span>
						  														  <span><input type=\"text\" name=\"deptName\" id=\"deptName\" style=\"width:275px\"/></span>
						  														  <input type=\"hidden\" name=\"loginId\" id=\"loginId\" style=\"width:275px\" value=\"$loginId\"/>
						  														  <input type=\"hidden\" name=\"password\" id=\"password\"  style=\"width:275px\" value=\"$password\"/>
						  													 </div>
						  													 <div>
						  														  
						  														  <span><input class=\"button-primary\" style=\"width:130px; margin-top:10px;\" type=\"submit\" value=\"Create Department\" /></span>
						  													 </div>
						  												</div>
						  										  </div>
						  									 </form></td></tr>";
						}
					}
				}
				else{
					$sResult .= "<tr><td><form method=\"post\" action=\"".BX_DOL_URL_MODULES."?r=banckle/settings/&action=signup\">
														  <div>
																<div style=\"width: 580px; padding: 5px; margin: 0px auto; line-height:26px; margin-top:10px;\">
																	 <div>
																		  <span><label>Banckle Login ID:</label></span>
																		  <span><input type=\"text\" name=\"loginId\" id=\"loginId\" style=\"width:275px\"/></span>
																	 </div>
																	 <div>
																		  <span><label>Password:</label></span>
																		  <span style=\"padding-left:43px\"><input type=\"password\" name=\"password\" id=\"password\"  style=\"width:275px\"/></span>
																	 </div>
																	 <div>
																		  <span><label>Email:</label></span>
																		  <span style=\"padding-left:66px\"><input type=\"text\" name=\"email\" id=\"email\"  style=\"width:275px\"/></span>
																	 </div>
																	 <div>
																		  <span>&nbsp;</span>
																		  <span><input type=\"submit\" value=\"Register\" / class=\"button-primary\" style=\" width:100px;\"> <span class=\"button-primary\" style=\" width:100px;\"><a href=\"".BX_DOL_URL_MODULES."?r=banckle/settings/\">Sign In</a></span></span>
																	 </div>
																</div>
														  </div>
													 </form></td></tr>";
				}
			}
			else
			{
				if (!isset($_REQUEST['action']))
				if ($_SERVER['REQUEST_METHOD'] == 'POST') {
					$loginId = $_POST['loginId'];
					$password = $_POST['password'];
					$token = '';
					$arr;
					$content = $this->banckleLiveChatRequest('https://apps.banckle.com/api/authenticate?userid=' . $loginId . '&password=' . $password . '&sourceSite=' . BX_DOL_URL_ROOT . '&platform=dolphin', "GET", "JSON", "");
					
					if ($content !== false) {
						$arr = json_decode($content, true);
						
						if ($arr === null || array_key_exists('error', $arr)){
							if($arr === null){
								$sResult .= '<tr><td><div class="wp-lc-error">Oops! This user ID does not exist. <br/><input style="margin-top:8px; width:100px; margin:auto;" type="submit" class="button-primary" onclick="parent.location=\''.BX_DOL_URL_MODULES.'?r=banckle/settings/\'" value="Try Again" /></div></td></tr>';
							}else{
								$sResult .= '<tr><td><div class="wp-lc-error">Oops!' . $arr['error']['details'] . '<br/><input style="margin-top:8px; width:100px; margin:auto;" type="submit" class="button-primary" onclick="parent.location=\''.BX_DOL_URL_MODULES.'?r=banckle/settings/\'" value="Try Again" /></div></td></tr>';
							}
						}
						else
						{
							//var_dump($arr);
							$token = $arr['return']['token'];
							
							//Get the XML document loaded into a variable
							$xmlDept = $this->banckleLiveChatRequest('https://apps.banckle.com/em/api/departments.xml?_token=' . $token, "GET", "XML", "");
							
							$xmlDept = new SimpleXMLElement(utf8_encode($xmlDept));
							
							if (count($xmlDept->department) == 0) {
								
								$sResult .= '<tr><td><form method="post" action="'.BX_DOL_URL_MODULES.'?r=banckle/settings/&action=dept">
																		  <div class="wp-lc-login">
																				<div style="width: 580px; padding: 5px; margin: 0px auto; line-height:26px;">
																					 <div class="row" style=" font-weight: normal; text-align: left;margin-left: 75px;">
																						  <b>It seems you have not created a department yet.</b> Its easy! So lets create a department now.
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Department:</label></span>
																						  <span class="formw"><input type="text" name="deptName" id="deptName" style="width:275px"/></span>
																						  <input type="hidden" name="loginId" id="loginId" style="width:275px" value="'.$loginId.'"/>
																						  <input type="hidden" name="password" id="password"  style="width:275px" value="'.$password.'"/>
																					 </div>
																					 <div class="row">
																						  <span class="label">&nbsp;</span>
																						  <span class="formw"><input type="submit" class="button-primary" value="Create Department" /></span>
																					 </div>
																				</div>

																		  </div>
																	 </form></td></tr>';
								
							}
							else{								
																
								$xmlDeploy = $this->banckleLiveChatRequest('https://apps.banckle.com/em/api/deployments.xml?_token=' . $token, "GET", "XML", "");
								$xmlDeploy = new SimpleXMLElement(utf8_encode($xmlDeploy));
								
								if (count($xmlDeploy->deployment) > 0) {
									$sResult .= '<tr><td><form method="post" action="'.BX_DOL_URL_MODULES .'?r=banckle/updateoptions/">										  
																		  <div class="wp-lc-deploy">

																				<div style="width: 580px; padding: 5px; margin: 0px auto; line-height:26px">
																					 <div class="row">
																						  <span class="label"><label>Select Deployment:</label></span>
																						  <span class="formw">
																								<select id="me_bcl_script" name="me_bcl_script"  style="width:140px">';
																 
																			for ($i = 0; $i < count($xmlDeploy->deployment); $i++) {
																				 $sResult .= '<option value="' . $xmlDeploy->deployment[$i]->id . '">' . $xmlDeploy->deployment[$i]->name . '</option>';
																			}
									$sResult .= '
																	</select>
															  </span>
														 </div>
														 <div class="row">
															  <span class="label">
																  <!--input type="hidden" name="me_bcl_script" id="me_bcl_script" value="'.$xmlDeploy->deployment[0]->id.'"/-->
																	<input type="hidden" name="me_bcl_loginId" id="me_bcl_loginId" value="'.$loginId.'"/>
																	<input type="hidden" name="me_bcl_password" id="me_bcl_password"  value="'.$password.'"/>
																	<input type="hidden" name="me_bcl_deptId" id="me_bcl_deptId"  value="'.$xmlDeploy->deployment[0]->departments.'"/>
															  </span>
															  <span class="formw"><input type="submit" class="button-active" value="Activate Live Chat" /></span>
														 </div>
													</div>

											  </div>
										 </form></td></tr>';
								}
								else{
									$sResult .= '<tr><td><form method="post" action="'.BX_DOL_URL_MODULES .'?r=banckle/updateoptions/&action=dept">
																			  <div class="wp-lc-login">
																					<div style="width: 580px; padding: 5px; margin: 0px auto; line-height:26px;">
																						 <div class="row" style=" font-weight: normal; text-align: left;margin-left: 75px;">
																							  <b>It seems you have not added a deployment yet.</b> Its easy! So lets add a deployment.
																						 </div>
																						 <div class="row">
																							  <input type="hidden" name="deptId" id="deptId" style="width:275px" value="'.$xmlDept->department[0]->id.'"/>
																							  <input type="hidden" name="deptName" id="deptName" style="width:275px" value="'.$xmlDept->department[0]->displayName.'"/>
																							  <input type="hidden" name="loginId" id="loginId" style="width:275px" value="'.$loginId.'"/>
																							  <input type="hidden" name="password" id="password"  style="width:275px" value="'.$password.'"/>
																						 </div>
																						 <div class="row">
																							  <span class="label">&nbsp;</span>
																							  <span class="formw"><input type="submit" class="button-primary" value="Create Deployment" /></span>
																						 </div>
																					</div>
																			  </div>
																		 </form></td></tr>';
								}								
							}
						}
						
					}
					else{
						$sResult .= '<tr><td>Network Error</td></tr>';
					}						
				}
				else{
					$sResult .= "<tr><td><form method=\"post\" action=\"".BX_DOL_URL_MODULES."?r=banckle/settings/\">
														  <div>


																<div class=\"login-bg\">
																	 <div>
																		  <span><label style=\"color:#343434; font:12px arial; font-weight:bold;\">Banckle Login ID:</label></span>
																		  <span><input type=\"text\" name=\"loginId\" id=\"loginId\" style=\"width:275px; ; border:1px solid #cccccc; font:12px arial; font-weight:bold; padding:2px;\"/></span>
																	 </div>
																	 <div style=\"margin-top:10px;\">
																		  <span><label style=\"color:#343434; font:12px arial; font-weight:bold; padding-left:35px;\">Password:</label></span>
																		  <span><input type=\"password\" name=\"password\" id=\"password\"  style=\"width:275px; ; border:1px solid #cccccc; font:12px arial; font-weight:bold; padding:2px;\"/></span>
																	 </div>
																	 <div>
																		  <span>&nbsp;</span>
																		  <span class=\"continue-btn\"><input type=\"submit\"  value=\"Continue\"></span>
																	 </div>
																	 
																	 <div class=\" bottom-text\">
																		  <span>Don't have a Banckle account? Please <a href=\"".BX_DOL_URL_MODULES."?r=banckle/settings/&action=signup\" target=\"_blank\">Sign up.</a></span>
																	 </div>
																	 
																</div>

														  </div> <div><img src=\"me/banckle/templates/base/images/powered-by-banckle.png\" / width=\"125px\" height=\"53px\" style=\"float:right;margin-top:10px\"></div>
														  
														  
													 </form></td></tr>";
				}				
			}
		}
		else{
			if (isset($_REQUEST['action']) && $_REQUEST['action'] === "updateDeploy") {
				$loginId = $_POST['loginId'];
				$password = $_POST['password'];
				$token = $_POST['token'];
				$deployId = $_POST['deployId'];
				$deployment = $_POST['deployment'];
				$departments = $_POST['departments'];
				$title = $_POST['title'];
				$copyright = $_POST['copyright'];
				$inviteMessage = $_POST['inviteMessage'];
				$unavailableMessage = $_POST['unavailableMessage'];
				$waitingMessage = $_POST['waitingMessage'];
				$welcomeMessage = $_POST['welcomeMessage'];
				$finalMessage = $_POST['finalMessage'];
				$location = $_POST['blcLocation'];

				$deployXML = new SimpleXMLElement("<?xml version=\"1.0\" encoding=\"UTF-8\"?><deployment></deployment>");
				$deployXML->addChild("name", $deployment);
				$deployXML->addChild("theme", "Theme-4");
				$deployXML->addChild("title", $title);
				$deployXML->addChild("copyright", $copyright);
				$deployXML->addChild("unavailableMessage", $unavailableMessage);
				$deployXML->addChild("waitingMessage", $waitingMessage);
				$deployXML->addChild("welcomeMessage", $welcomeMessage);
				$deployXML->addChild("finalMessage", $finalMessage);
				$deployXML->addChild("inviteMessage", $inviteMessage);
				$deployXML->addChild("exitSurvey", "");
				$deployXML->addChild("enableAutoInvite", "false");
				$deployXML->addChild("inviteTimeout", "60");
				$deployXML->addChild("autoInviteImage", "");
				$deployXML->addChild("enableProactiveInvite", "true");
				$deployXML->addChild("enableInvitationFilter", "false");
				$deployXML->addChild("invitationFilterType", "0");
				$deployXML->addChild("linkType", "0");
				$deployXML->addChild("themeFlags", "0");

				$xmlDeploy = $this->banckleLiveChatRequest('https://apps.banckle.com/em/api/deployments/' . $deployId . '.xml?_token=' . $token, "PUT", "XML", $deployXML->asXML());				
				$this->_oDb->updateOption($iId,'me_bcl_location',$location);
				
				$sResult .= '<tr><td><div class="wp-lc-mesg-success">Deployment is updated!<br><input type="button" class="button-primary" value="OK" style="width:100px; margin:auto;" onclick="parent.location=\''.BX_DOL_URL_MODULES.'?r=banckle/settings/\'" /></div></td></tr>';				
			}
			if (isset($_REQUEST['action']) && $_REQUEST['action'] === "custom") {
				$loginId = $this->_oDb->getOption($iId,'me_bcl_loginId');
				$password = $this->_oDb->getOption($iId,'me_bcl_password');
				$deployId = $this->_oDb->getOption($iId,'me_bcl_script');
				$content = $this->banckleLiveChatRequest('https://apps.banckle.com/api/authenticate?userid=' . $loginId . '&password=' . $password . '&sourceSite=' . BX_DOL_URL_ROOT . '&platform=dolphin', "GET", "JSON", "");
				
				if ($content !== false) {
					$arr = json_decode($content, true);
					if (array_key_exists('error', $arr)) {
						$sResult .= '<tr><td><div class="wp-lc-error">Oops, '. $arr['error']['details'] . '.<br/><input style="margin-top:8px; width:100px; margin:auto;" type="submit" class="button-primary" onclick="parent.location=\''.BX_DOL_URL_MODULES.'?r=banckle/settings/\'" value="Try Again" /></div></td></tr>';
					}
					else{
						$token = $arr['return']['token'];
						$xmlDeploy = $this->banckleLiveChatRequest('https://apps.banckle.com/em/api/deployments.xml?_token=' . $token, "GET", "XML", "");
						$xmlDeploy = new SimpleXMLElement(utf8_encode($xmlDeploy));
						
						$sResult .= '<tr><td><form method="post" action="'.BX_DOL_URL_MODULES.'?r=banckle/settings/&action=updateDeploy">
																<div class="wp-lc-login-form">
																	 <div class="wp-lc-login-form-btm">
																		  <div style="width: 580px; padding: 5px; margin: 0px auto; line-height:26px;">
																				<fieldset>
																					 <legend>Deployment</legend>
																					 <div class="row">
																						  <span class="label"><label>Deployment:</label></span>
																						  <span class="formw"><input type="text" name="deployment" id="deployment" style="width:275px" value="'. $xmlDeploy->deployment[0]->name.'"/></span>
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Title:</label></span>
																						  <span class="formw"><input type="text" name="title" id="title" style="width:275px"  value="'.$xmlDeploy->deployment[0]->title.'"/></span>
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Copyright Text:</label></span>
																						  <span class="formw"><input type="text" name="copyright" id="copyright" style="width:275px"  value="'.$xmlDeploy->deployment[0]->copyright.'"/></span>
																					 </div>
																				</fieldset>
																				<fieldset>
																					 <legend>Messages</legend>
																					 <div class="row">
																						  <span class="label"><label>Invite:</label></span>
																						  <span class="formw"><textarea name="inviteMessage" id="inviteMessage" style="width:275px">'.$xmlDeploy->deployment[0]->inviteMessage.'</textarea></span>
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Online:</label></span>
																						  <span class="formw"><textarea name="welcomeMessage" id="welcomeMessage" style="width:275px">'.$xmlDeploy->deployment[0]->welcomeMessage.'</textarea></span>
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Offline:</label></span>
																						  <span class="formw"><textarea name="unavailableMessage" id="unavailableMessage" style="width:275px">'.$xmlDeploy->deployment[0]->unavailableMessage.'</textarea></span>
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Waiting:</label></span>
																						  <span class="formw"><textarea name="waitingMessage" id="waitingMessage" style="width:275px">'.$xmlDeploy->deployment[0]->waitingMessage.'</textarea></span>
																					 </div>
																					 <div class="row">
																						  <span class="label"><label>Exit:</label></span>
																						  <span class="formw"><textarea name="finalMessage" id="finalMessage" style="width:275px">'.$xmlDeploy->deployment[0]->finalMessage.'</textarea></span>
																					 </div>
																				</fieldset>
																				<fieldset>
																					 <legend>Appearance</legend>
																					 <div class="row">
																						  <span class="label"><label>Position</label></span>
																						  <span class="formw"><select name="blcLocation" id="blcLocation"><option value="banckleLiveChatWidget">Widget</option><option value="banckleLiveChatTopLeft">Top Left</option><option value="banckleLiveChatTopRight">Top Right</option><option value="banckleLiveChatBottomLeft">Bottom Left</option><option value="banckleLiveChatBottomRight">Bottom Right</option></select> </span>
																					 </div>
																				</fieldset>
																				<div class="row">
																					 <!--span class="label"><label>Department:</label></span-->
																					 <span class="formw">
																						  <input type="hidden" name="departments" id="departments" value="'.$xmlDeploy->deployment[0]->departments.'" />
																						  <input type="hidden" name="loginId" id="loginId" style="width:275px" value="'.$loginId.'"/>
																						  <input type="hidden" name="password" id="password"  style="width:275px" value="'.$password.'"/>
																						  <input type="hidden" name="deployId" id="deployId"  style="width:275px" value="'.$xmlDeploy->deployment[0]->id.'"/>
																						  <input type="hidden" name="token" id="token" value="'.$token.'" style="width:275px"/>
																					 </span>
																				</div>
																				<div class="row">
																					 <span class="label">&nbsp;</span>
																					 <span class="formw"><input type="submit" class="button-primary" value="Update Deployment" / style="width:150px; display:block; float:left; margin-bottom:8px;"><input type="button" class="button-primary-cancle"  value="Cancel" onclick="parent.location=\''.BX_DOL_URL_MODULES.'?r=banckle/settings/ \'" /></span>
																				</div>

																		  </div><!--width 580px; -->
																	 </div><!--only for bottom bg -->
																</div><!--wp-lc-login-form -->
														  </form></td></tr>';
					}
				}
			}
			if (!isset($_REQUEST['action']) || ((isset($_REQUEST['action']) && $_REQUEST['action'] === "deploy"))) {
				$sResult .= '<tr><td>Congratulations! Banckle Live Chat Plugin has been successfully integrated and activated for your Dolphin website. Please sign into <a target="_blank" href="https://apps.banckle.com/livechat">Banckle Live Chat</a> to start chatting with your visitors.<br></td></tr>
				<tr><td><form method="post" action="'.BX_DOL_URL_MODULES .'?r=banckle/updateoptions/" style="display:inline;">
				<input type="hidden" name="me_bcl_script" id="me_bcl_script" value=""/>
				<input type="hidden" name="me_bcl_loginId" id="me_bcl_loginId" value=""/>
				<input type="hidden" name="me_bcl_password" id="me_bcl_password"  value=""/>
				<input type="hidden" name="me_bcl_location" id="me_bcl_location" value=""/>
												
				<input style="margin-top:8px; width:150px;" type="submit" class="button-primary" value="Deactivate Live Chat" />
				</form></td></tr>';
				
				$me_bcl_loginId = $this->_oDb->getOption($iId,'me_bcl_loginId');
				$me_bcl_password = $this->_oDb->getOption($iId,'me_bcl_password');
				$me_bcl_script = $this->_oDb->getOption($iId,'me_bcl_script');
				
				$sResult .= '<tr><td><form method="post" action="'.BX_DOL_URL_MODULES.'?r=banckle/settings/&action=custom" style="display:inline;">
							<input type="hidden" name="loginId" id="loginId" value="'.$me_bcl_loginId.'"/>
							<input type="hidden" name="password" id="password" value="'.$me_bcl_password.'"/>
							<input type="hidden" name="deployId" id="deployId" value="'.$me_bcl_script.'"/>
							<input style="margin-top:8px; width:150px;" type="submit" class="button-primary" value="Customize Live Chat" />
							 </form></td></tr>';
			}
		}
		
		$sResult .= "</table></div>";		  						 
		
		echo DesignBoxAdmin ('<img src="me/banckle/templates/base/images/live-chat_32.png" />Banckle Live Chat - Settings', $sResult, $aMenu); // dsiplay box
        
        $this->_oTemplate->pageCodeAdmin (_t('_me_bcl')); // output is completed, admin page will be displaed here
	}
	
	function actionUpdateoptions(){
	
		if (!$GLOBALS['logged']['admin']) { // check access to the page
            $this->_oTemplate->displayAccessDenied ();
            return;
        }

        $this->_oTemplate->pageStart(); // all the code below will be wrapped by the admin design

	    $iId = $this->_oDb->getSettingsCategory(); // get our setting category id
	    if(empty($iId)) { // if category is not found display page not found
            echo MsgBox(_t('_sys_request_page_not_found_cpt'));
            $this->_oTemplate->pageCodeAdmin (_t('_me_bcl'));
            return;
        }
		
		$aMenu = array(
                'me_bcl_main'      => array('title' => 'Dashboard', 'href' => BX_DOL_URL_MODULES . '?r=banckle/administration/'), 
                'me_bcl_settings'  => array('title' => 'Settings', 'href' => BX_DOL_URL_MODULES . '?r=banckle/settings/'),
            );
		
		//$me_bcl_script = $this->_oDb->getOption($iId,'me_bcl_script');
		
		
		
		if($_SERVER['REQUEST_METHOD'] == 'POST') {
		
			$arr[me_bcl_loginId] = $_POST['me_bcl_loginId'];
			$arr[me_bcl_password] = $_POST['me_bcl_password'];
			$arr[me_bcl_script] = $_POST['me_bcl_script'];
			$arr[me_bcl_deptId] = $_POST['me_bcl_deptId'];
			$arr[me_bcl_location] = $_POST['me_bcl_location'];
			if($_POST['me_bcl_script'] != "")
			{
			$widget = '<script type="text/javascript" async="yes" src="https://apps.banckle.com/em/visitor.do?dep='.$_POST['me_bcl_script'].'"></script>
<div id="banckleLiveChatButton1" class="banckleLiveChatBottomRight" style="overflow: hidden; margin: 0pt; padding: 0pt; background: none repeat scroll 0% 0% transparent; width: 264px; height: 70px; z-index: 1000000000; position: fixed; bottom: -3px; right: 20px;">
<!-- Chat Link Code -->
<a href="javascript:;" onclick="blc_startChat(); hidebcl(); return false;"><img id="blcstatus" src="https://apps.banckle.com/em/onlineImg.do?d='.$_POST['me_bcl_script'].'&a=/images/live-chat-available.png&u=/images/leave-your-message.png" alt="Live Chat" /></a>
</div>
<script type="text/javascript">
function hidebcl(){
document.getElementById("banckleLiveChatButton1").style.display = "none";
}
function updatestatus()
{
	document.getElementById("blcstatus").src = document.getElementById("blcstatus").src;	
}
var bclscript = "'.$_POST['me_bcl_script'].'";
//setTimeout("bs_startChat({dep:bclscript});",1000);
setInterval("updatestatus();",2000);
</script>';
			$this->_oDb->updateWidget($widget);
			
			$result = $this->_oDb->setOption($iId,$arr);
			
			if($result)
			{
				$sResult .= "<div style=\"font:12px arial; background:#f9f9f9; border:1px solid #dfdfdf; padding:10px; height:50px;\">Activated Successfully.</div>";				
			}
		}
		else
		{
			$widget = "";
			$this->_oDb->updateWidget($widget);
			
			$result = $this->_oDb->setOption($iId,$arr);
			
			if($result)
			{
				$sResult .= "<div style=\"font:12px arial; background:#f9f9f9; border:1px solid #dfdfdf; padding:10px; height:50px;\">Deactivated Successfully.</div>";				
			}
		}
			
		}
		
		
		$sResult .= $this->cssTxt;
		echo DesignBoxAdmin (' <img src="me/banckle/templates/base/images/live-chat_32.png" /> Banckle Live Chat - Dashboard', $sResult, $aMenu); // dsiplay box
        
        $this->_oTemplate->pageCodeAdmin (_t('_me_bcl')); // output is completed, admin page will be displaed here
		
	}


    function actionAdministration () {

        if (!$GLOBALS['logged']['admin']) { // check access to the page
            $this->_oTemplate->displayAccessDenied ();
            return;
        }

        $this->_oTemplate->pageStart(); // all the code below will be wrapped by the admin design

	    $iId = $this->_oDb->getSettingsCategory(); // get our setting category id
	    if(empty($iId)) { // if category is not found display page not found
            echo MsgBox(_t('_sys_request_page_not_found_cpt'));
            $this->_oTemplate->pageCodeAdmin (_t('_me_bcl'));
            return;
        }
		
		
		$aMenu = array(
                'me_bcl_main'      => array('title' => 'Dashboard', 'href' => BX_DOL_URL_MODULES . '?r=banckle/administration/'), 
                'me_bcl_settings'  => array('title' => 'Settings', 'href' => BX_DOL_URL_MODULES . '?r=banckle/settings/'),
            );
		
		$me_bcl_script = $this->_oDb->getOption($iId,'me_bcl_script');
				
		
		if($me_bcl_script == "")
		{
			$sResult .= '<strong>Banckle Live Chat is disabled. Please go to <a href="'.BX_DOL_URL_MODULES.'?r=banckle/settings/"> page</a> to enable it.</strong>';
		}
		
		$sResult .= '<div id="dashboarddiv"><iframe id="dashboardiframe" src="http://apps.banckle.com/livechat" height=800 width=98% scrolling="yes"></iframe></div>      <a href="http://apps.banckle.com/livechat" target="_newWindow" onClick="javascript:document.getElementById(\'dashboarddiv\').innerHTML=\'\'; ">Dashboard in a new window!</a>.';
		
		//$sResult = BX_DOL_URL_MODULES . "Testing BCL";

        $sResult .= $this->cssTxt;
		
		$sResult .= '<style>
		div.adm-db-content{		
		width:1000px;
		height:850px;
		}
		div.adm-design-box{
		width:1000px;
		}
		</style>';
		
        echo DesignBoxAdmin ('Banckle Live Chat - Dashboard', $sResult, $aMenu); // dsiplay box
        
        $this->_oTemplate->pageCodeAdmin (_t('_me_bcl')); // output is completed, admin page will be displaed here
    }    
}

?>
