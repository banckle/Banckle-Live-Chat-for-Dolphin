<?
/***************************************************************************
*                            Dolphin Smart Community Builder
*                              -------------------
*     begin                : Mon Mar 23 2006
*     copyright            : (C) 2007 BoonEx Group
*     website              : http://www.boonex.com
* This file is part of Dolphin - Smart Community Builder
*
* Dolphin is free software; you can redistribute it and/or modify it under
* the terms of the GNU General Public License as published by the
* Free Software Foundation; either version 2 of the
* License, or  any later version.
*
* Dolphin is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY;
* without even the implied warranty of  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.
* See the GNU General Public License for more details.
* You should have received a copy of the GNU General Public License along with Dolphin,
* see license.txt file; if not, write to marketing@boonex.com
***************************************************************************/

bx_import('BxDolModuleDb');

class MeBclDb extends BxDolModuleDb {

	function MeBclDb(&$oConfig) {
		parent::BxDolModuleDb();
        $this->_sPrefix = $oConfig->getDbPrefix();
    }

    function getSettingsCategory() {
        return $this->getOne("SELECT `ID` FROM `sys_options_cats` WHERE `name` = 'My Banckle' LIMIT 1");
    }
	
	function getOption($Id,$option='')
	{
		if($option == '')
			return $this->getAll("SELECT * FROM `sys_options` WHERE `kateg` = '$Id'");
		else
			return $this->getOne("SELECT `Value` FROM `sys_options` WHERE `Name` = '$option' LIMIT 1");
	}
    
	function updateOption($iId,$option,$value)
	{
		$qry = "UPDATE sys_options SET VALUE = '$value' WHERE Name = '$option' AND kateg = '$Id'";		
		mysql_query($qry) or die (mysql_error());
		
		return true;
	}
	
	function setOption($Id,$arr)
	{
		foreach($arr as $name => $value)
		{
			$qry = "UPDATE sys_options SET VALUE = '$value' WHERE Name = '$name' AND kateg = '$Id' AND value != '$value';";		
			mysql_query($qry) or die (mysql_error());
		}		
				
		return true;
	}
	
	function updateWidget($text)
	{
		if($text == "") $active = 0 ; else $active = 1;
		$qry = "UPDATE sys_banners SET Text = '$text', Active = '$active' WHERE Title = 'BCLWidget';";
		mysql_query($qry) or die (mysql_error());
		return true;
	}
	
	
}

?>
