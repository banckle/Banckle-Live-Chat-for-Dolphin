-- settings
SET @iCategId = (SELECT `ID` FROM `sys_options_cats` WHERE `name` = 'My Banckle' LIMIT 1);
DELETE FROM `sys_options` WHERE `kateg` = @iCategId;
DELETE FROM `sys_options_cats` WHERE `ID` = @iCategId;
DELETE FROM `sys_options` WHERE `Name` = 'me_blgg_permalinks';

-- permalinks
DELETE FROM `sys_permalinks` WHERE `standard` = 'modules/?r=banckle/';

-- admin menu
DELETE FROM `sys_menu_admin` WHERE `name` = 'me_bcl';

-- widget box
DELETE FROM `sys_banners` WHERE `title` = 'BCLWidget';
