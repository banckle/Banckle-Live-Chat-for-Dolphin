-- settings
SET @iMaxOrder = (SELECT `menu_order` + 1 FROM `sys_options_cats` ORDER BY `menu_order` DESC LIMIT 1);
INSERT INTO `sys_options_cats` (`name`, `menu_order`) VALUES ('My Banckle', @iMaxOrder);
SET @iCategId = (SELECT LAST_INSERT_ID());
INSERT INTO `sys_options` (`Name`, `VALUE`, `kateg`, `desc`, `Type`, `check`, `err_text`, `order_in_kateg`, `AvailableValues`) VALUES
('me_blgg_permalinks', 'on', 26, 'Enable friendly permalinks in Banckle Live Chat', 'checkbox', '', '', '0', ''),
('me_bcl_loginId', '', @iCategId, 'Banckle User Login Id', 'text', '', '', '1', ''),
('me_bcl_password', '', @iCategId, 'Banckle User Password', 'text', '', '', '2', ''),
('me_bcl_deptId', '', @iCategId, 'Banckle Department Id', 'text', '', '', '3', ''),
('me_bcl_script', '', @iCategId, 'Banckle Deployment Id', 'text', '', '', '4', ''),
('me_bcl_location', '', @iCategId, 'Banckle Deployment Id', 'text', '', '', '5', '');

-- permalinks
INSERT INTO `sys_permalinks` VALUES (NULL, 'modules/?r=banckle/', 'm/banckle/', 'me_bcl_permalinks');

-- admin menu
SET @iMax = (SELECT MAX(`order`) FROM `sys_menu_admin` WHERE `parent_id` = '2');
INSERT IGNORE INTO `sys_menu_admin` (`parent_id`, `name`, `title`, `url`, `description`, `icon`, `order`) VALUES
(2, 'me_bcl', '_me_bcl', '{siteUrl}modules/?r=banckle/administration/', 'Banckle Live Chat', 'modules/me/banckle/|icon.png', @iMax+1);

-- widget box
INSERT IGNORE INTO `sys_banners` (`ID`, `Title`, `Url`, `Text`, `Active`, `Created`,`campaign_start`,`campaign_end`,`Position`,`lhshift`,`lvshift`,`rhshift`,`rvshift`) VALUES
(NULL, 'BCLWidget', '', '', '0',CURDATE(),DATE_SUB(CURDATE(), INTERVAL 1 MONTH),DATE_ADD(CURDATE(), INTERVAL 2 YEAR),4,0,0,0,0);